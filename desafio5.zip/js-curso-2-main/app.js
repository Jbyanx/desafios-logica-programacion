let titulo = document.querySelector('h1');
titulo.innerHTML = "Hora del Desafío";

function fConsole(){
    console.log("El boton fue clickeado");
}

function fPrompt(){
    let ciudad = prompt("Nombra una ciudad de Brasil");
    alert(`Estuve en ${ciudad} y me acorde de ti`);
}

function fAlert(){
    alert("Yo amo JS");
}

function suma(){
    let numero1 = parseInt(prompt("Dime el primer numero"));
    let numero2 = parseInt(prompt("Dime el segundo numero"));

    alert(`La suma de ${numero1}+${numero2}=${numero1+numero2}`);
}